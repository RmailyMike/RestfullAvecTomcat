/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Rest;

import javax.ws.rs.GET;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author Mike
 */
@Path("StudentController")
public class StudentController {
    
    /**
     *
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    @GET
    @Path("/getAllStudents")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<StudentModel> getAllStudents() throws ClassNotFoundException, SQLException{
        ArrayList<StudentModel> StudentModelArray = new ArrayList<>();
        Connection con = null;
        String Username = "RestfullServicesDB";
        String Password = "RestfullServicesDB";
        String query ="select * from STUDENT";
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        con = DriverManager.getConnection("jdbc:derby://localhost:1527/RestfullServicesDB",Username,Password);
        Statement st= con.createStatement();
        ResultSet rs = st.executeQuery(query);
        while(rs.next()){
            StudentModel StudentModel = new StudentModel();
               StudentModel.setEmail(rs.getString("Email"));
               StudentModel.setId(rs.getInt("id"));
               StudentModel.setName(rs.getString("name"));
               StudentModel.setDateOfBirth(rs.getDate("DateOfBirth"));
               StudentModelArray.add(StudentModel);
        }
        return StudentModelArray;
    }
}
